% m1 must be a visible image, m2 is an infrared image !!!

m1=imread('C:\Users\msi\Desktop\ffvi\visible\VIS.bmp');   % m1 -> visible image
m2=imread('C:\Users\msi\Desktop\ffvi\infrared\IR.bmp');   % m2 -> infrared image
res=ffvi(m1,m2);
imshow(res)
